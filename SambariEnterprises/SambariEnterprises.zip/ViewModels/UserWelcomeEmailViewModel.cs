﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SambariEnterprises.ViewModels
{
    public class UserWelcomeEmailViewModel
    {
        public string ToName { get; set; }
    }
}